MODDIR=${0%/*}
#rm rubbish
rm -rf $(dirname "$0")