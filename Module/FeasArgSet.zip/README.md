# FeasArgSet
一个可以自定义小米Feas配置的功能
需要设备本身支持小米feas功能
自己写自己设备的feas路径
(开关，fps，scaling a b 的节点)
配置文件位于本模块的config文件夹
path.conf写你的设备的路径
package.conf写需要开启feas的游戏包名
以及目标帧率等参数
修改后需要重新执行service.sh以应用新配置
