20231014更新:
增加更多节点: 
normal_frame_keep_count
min_freq_limit_level
max_freq_limit_level
强烈建议修改原版配置文件

20230901更新: 
增加自动生成节点功能

20230814更新:
内置k40g bocchi节点

20230809更新:
内置mtk feas节点，
优先mtkPandora路径
高通可以自己写节点，也可以将节点反馈给作者
